# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import unicode_literals
from django.contrib import messages
from django.template.response import TemplateResponse
from django.shortcuts import render,redirect
from cryptography.fernet import Fernet
from userprofile.forms import RegisterForm,LoginForm
from userprofile.models import User, UserToken
# Create your views here.
def registration(request):
    login = RegisterForm(request.POST or None)
    if login.is_valid():
        username = login.cleaned_data.get("username")
        phone = login.cleaned_data.get("phone")
        password = login.cleaned_data.get("password")
        email = login.cleaned_data.get("email")
        country = login.cleaned_data.get("country")
        key = Fernet.generate_key()
        cipher_suite = Fernet(key)
        encoded_text = cipher_suite.encrypt(str(password))
        user = User.objects.create(
                email = str(email) if str(email) else None,
                phone = phone,
                user_name = str(username),
                is_active = True,
                country = country,
                password = encoded_text,
                key=key
            )
        token = UserToken.objects.create(user = user, access_token = encoded_text)
        return redirect('userprofile:login')

    ctx={"login":login}
    return TemplateResponse(request,"userprofile/register.html",ctx)


def login(request):
    form = LoginForm(request.POST or None)
    ctx = { "form": form,
            "message": ""
         }
    if form.is_valid():
        phone = form.cleaned_data.get('phone')
        password = form.cleaned_data.get('password')
        sis = User.objects.filter(phone=phone)
        if sis.exists():
            usr = sis.first()
            return redirect('articles:all_posts', pk=usr.pk)
    return TemplateResponse(request,"userprofile/login.html",ctx)