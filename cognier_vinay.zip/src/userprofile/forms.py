from django import forms
from django.contrib.auth import forms as django_forms, update_session_auth_hash
from userprofile.models import User, UserToken
from cryptography.fernet import Fernet

from django import forms

class LoginForm(forms.Form):

    
    phone = forms.CharField(label = "Phone", required = True)
    password = forms.CharField(label = "Password",widget = forms.PasswordInput,required = True)

    def clean(self):
        phone = self.cleaned_data.get("phone")
        password = self.cleaned_data.get("password")

        values = {
                "phone" : phone,
                "password" : password
            }
        sis = User.objects.filter(phone=phone)
        if sis.exists():
            usr = sis.first()
            decrypt = usr.decrypt_password()
            if str(decrypt) == str(password):
                usrtok = UserToken.objects.filter(id = usr.id)
                acctok = ''
                if usrtok.exists():
                    acctok = usrtok.first().access_token
                else:
                    key = Fernet.generate_key()
                    cipher_suite = Fernet(str(sis.first().key))
                    acctok = cipher_suite.encrypt(str(password))
                

            else:    
                raise forms.ValidationError("Please enter correct password or mobile number")
        else:
          raise forms.ValidationError("User does not exists.")
        return values



class RegisterForm(forms.Form):
    username = forms.CharField(max_length = 50,label = "UserName")
    phone = forms.CharField(label = "Phone", required = True)
    password = forms.CharField(max_length=20,label = "Password",widget = forms.PasswordInput)
    confirm = forms.CharField(max_length=20,label ="Confirm Password",widget = forms.PasswordInput)
    
    def clean(self):
        username = self.cleaned_data.get("username")
        phone = self.cleaned_data.get("phone")
        password = self.cleaned_data.get("password")
        confirm = self.cleaned_data.get("confirm")
        user = User.objects.filter(phone = str(phone))
        if password and confirm and password != confirm:
            raise forms.ValidationError("Password Doesnt match")
        if user.exists():
          raise forms.ValidationError("User already exists with given mobile number.")
        values = {
            "username" : username,
            "password" : password,
            "phone": phone,

        }
        return values


