from django import forms
from django.contrib.auth import forms as django_forms, update_session_auth_hash
from userprofile.models import User, UserToken
from articles.models import Articles, EditArticles
from django import forms


class Editform(forms.ModelForm):
    # header = forms.CharField(label="Header",max_length=200)
    # article = forms.CharField(label = "Post")

    class Meta:
        model = Articles
        fields = ['header', 'article']

    def __init__(self, *args, **kwargs):
        super(Editform, self).__init__(*args, **kwargs)
        article =  kwargs['instance']
        self.fields['header'].initial = article.header
        self.fields['article'].initial = article.article 

    def clean(self):
        header = self.cleaned_data.get("header")
        article = self.cleaned_data.get("article")
        values = {
                "header" : header,
                "article" : article
            }

        return values