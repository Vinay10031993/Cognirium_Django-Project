# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.template.response import TemplateResponse
from django.shortcuts import render
from .models import Articles, EditArticles
from userprofile.models import User
import json
from django.shortcuts import render,redirect
from django.http import JsonResponse
from .forms import Editform
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
def all_posts(request,pk):
    art = Articles.objects.all().order_by('created')
    art = [ar for ar in reversed(art)]
    ctx = {
        "art": art,
        "pk": pk
    }
    return TemplateResponse(request,"articles/posts.html", ctx)

@csrf_exempt
def add_posts(request):
    if request.method == "POST":
        data = json.loads(request.POST.get('response_data'))
        user = User.objects.filter(id=data['pk'])
        if user.exists():
            Articles.objects.create(user=user.first(), article = str(data['payload']), header=str(data['header']))
            res = {"status": 200,
            "message": "success"}
            return JsonResponse(res)
        else:
            res = {"status": 200,
            "message": "Update Failed"}
            return JsonResponse(res)


@csrf_exempt
def edit_message(request, pk):

    instance = Articles.objects.get(pk=pk)
    forms = Editform(request.POST or None, instance = instance)
    if forms.is_valid():
        EditArticles.objects.get_or_create(article=instance, edited_text = forms.cleaned_data['article'])
        return redirect('articles:all_posts', pk=instance.user.pk)
    ctx = {"forms": forms}
    

    return TemplateResponse(request,"articles/edit_info.html",ctx)

