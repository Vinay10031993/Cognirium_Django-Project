from django.conf.urls import url, include
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^all_posts/(?P<pk>\d+)/', views.all_posts, name="all_posts" ),
    url(r'^add_posts/', views.add_posts, name="add_posts" ),
    url(r'^edit_message/(?P<pk>\d+)/', views.edit_message, name="edit_message" ),
    
]