# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from userprofile.models import User


class Articles(models.Model):
    article = models.TextField(null=True)
    header = models.TextField(null=True)
    user = models.name = models.ForeignKey('userprofile.user', related_name='user_article', on_delete=models.CASCADE)
    created = models.DateField(auto_now_add=True)
    updated = models.DateField(auto_now=True)


class EditArticles(models.Model):
    article = models.ForeignKey(Articles, blank=True, null=True)
    edited_text = models.TextField(null=True)
    created = models.DateField(auto_now_add=True)
    updated = models.DateField(auto_now=True)
    is_approved = models.BooleanField(default = "False")
