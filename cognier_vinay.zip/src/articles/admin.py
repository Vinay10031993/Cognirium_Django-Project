from __future__ import unicode_literals

from django.contrib import admin

from .models import Articles,EditArticles
admin.site.register(Articles)
admin.site.register(EditArticles)