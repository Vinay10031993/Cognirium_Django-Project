from django.conf.urls import url, include
from django.contrib import admin
from . import views
print "-----------------------------"
urlpatterns = [
    url(r'^products-list/', views.get_items, name="get-all-products" )
]
