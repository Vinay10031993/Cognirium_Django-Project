# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.template.response import TemplateResponse
from django.shortcuts import render
# from .models import User
from .models import Products

# Create your views here.
def get_items(request,*ard, **args):
    print "=================="
    pas = Products.objects.all()
    ctx = {'product': pas}
    print ctx
    return TemplateResponse(request,"product/list.html",ctx)

